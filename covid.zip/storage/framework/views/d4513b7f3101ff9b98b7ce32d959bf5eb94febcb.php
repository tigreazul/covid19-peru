<!DOCTYPE html>
<html>
<head>
	<title>COVID-19</title>
</head>
<body>

	<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">

	<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
	<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
	<!------ Include the above in your HEAD tag  secure_asset ---------->
	<!-- <link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> -->

	<script src="https://code.highcharts.com/highcharts.js"></script>
	<script src="https://code.highcharts.com/modules/data.js"></script>
	<script src="https://code.highcharts.com/modules/series-label.js"></script>
	<script src="https://code.highcharts.com/modules/exporting.js"></script>
	<script src="https://code.highcharts.com/modules/export-data.js"></script>
	<script src="https://code.highcharts.com/modules/accessibility.js"></script>
	
	<!-- Additional files for the Highslide popup effect -->
	<script src="https://www.highcharts.com/media/com_demo/js/highslide-full.min.js"></script>
	<script src="https://www.highcharts.com/media/com_demo/js/highslide.config.js" charset="utf-8"></script>
	<link rel="stylesheet" type="text/css" href="https://www.highcharts.com/media/com_demo/css/highslide.css" />
	<script type="text/javascript" src="<?php echo e(asset('js/main.js?v=13')); ?>"></script>

    <nav class="navbar navbar-default navbar-fixed-top topbar">
		<div class="container-fluid">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">
					<span class="visible-xs">COVID-19</span>
					<span class="hidden-xs">COVID-19</span>
				</a>
				<p class="navbar-text">
					<a href="#" class="sidebar-toggle">
                        <i class="fa fa-bars"></i>
                    </a>
				</p>
			</div>

			<div class="navbar-collapse collapse" id="navbar-collapse-main">
				<ul class="nav navbar-nav navbar-right">
                    <li>
                        <button class="navbar-btn">
                            <i class="fa fa-bell"></i>
                        </button>
                    </li>
					<li class="dropdown">
						<button class="navbar-btn" data-toggle="dropdown">
							<img src="http://lorempixel.com/30/30/people" class="img-circle">
						</button>
						<ul class="dropdown-menu">
							<li><a href="#">Account</a></li>
							<li><a href="#">Dashboard</a></li>
							<li class="nav-divider"></li>
							<li><a href="#">Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	
	<article class="wrapper">
	    <aside class="sidebar">
	        <ul class="sidebar-nav">
			    <li class="active"><a href="#dashboard" data-toggle="tab"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
			    <li><a href="#configuration" data-toggle="tab"><i class="fa fa-cogs"></i> <span>Configuration</span></a></li>
			    <li><a href="#users" data-toggle="tab"><i class="fa fa-users"></i> <span>Users</span></a></li>
			    <li><a href="#mail" data-toggle="tab"><i class="fa fa-envelope"></i> <span>Mail</span></a></li>
		    </ul>
	    </aside>
	    
	    <section class="main">
	        <section class="tab-content">
	           <section class="tab-pane active fade in content" id="dashboard">
	                <div class="row">
	           			<div class="col-xs-6 col-sm-6">
							   </div>
							   <div class="alert alert-danger" role="alert" style="height: 62px;padding: 8px 0px 0px 0px;">
								   <div class="col-xs-6 col-sm-1">
									   <h4 style="margin-top: 15px;"><strong>PAIS:</strong></h4>
								   </div>
								   <div class="col-xs-6 col-sm-11">
									   <div>
										   <select id="pais" class="form-control" name="aa">
											   <!-- <option value="0">[SELECCIONE]</option> -->
											   <?php $__currentLoopData = $pais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												   <option value="<?php echo e($text->sigla); ?>"><?php echo e(strtoupper($text->pais)); ?></option>
											   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										   </select>
									   </div>
								   </div>
							   </div>
                        <!-- <div class="col-xs-6 col-sm-6">
                            <div class="alert alert-info" role="alert"> 
                                <h4>
                                    <strong> REPORTE: <?php echo e(date('Y-m-d')); ?> </strong> 
                                </h4>
                            </div>
                        </div> -->
                    </div>
					<div class="row">
	                    <div class="col-xs-6 col-sm-4">
	                        <div class="panel panel-primary">
	                            <div class="panel-body">
	                            	<strong class="text-primary">CONFIRMADO</strong>
	                                <br/>
	                                <span class="numeros text-primary"><?php echo e(number_format($total['peru']['confirmado'])); ?></span>
                                    <!-- <span class="adicional">+10</span> -->
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-xs-6 col-sm-4">
	                        <div class="panel panel-success">
	                            <div class="panel-body">
	                            	<strong class="text-success">RECUPERADO</strong>
	                                <br/>
	                                <span class="numeros text-success"><?php echo e(number_format($total['peru']['recuperado'])); ?></span>
	                            </div>
	                        </div>
	                    </div>
	                    <div class="col-xs-6 col-sm-4">
	                        <div class="panel panel-danger">
	                            <div class="panel-body">
	                            	<strong class="text-danger">MUERTES</strong>
	                                <br/>
	                                <span class="numeros text-danger"><?php echo e(number_format($total['peru']['muerte'])); ?></span>
	                            </div>
	                        </div>
	                    </div>
	                   	<div class="col-xs-12 col-sm-8">
	                       	<div class="panel panel-default">
	                           	<div class="panel-heading">
	                               ESTADISTICA
	                           	</div>
	                           	<div class="panel-body">
								   <!-- <img class="imagen_mundial img-responsive" src="" alt=""> -->
								   <figure class="highcharts-figure">
										<div id="chartContainer" style="height: 300px; width: 100%;"></div>
									</figure>

	                           	</div>
	                       	</div>
	                   	</div>
	                   <div class="col-xs-12 col-sm-4">
	                       <div class="panel panel-default">
	                           <div class="panel-heading">
                                    <strong>Departamentos </strong>
	                           </div>
	                           <div class="panel-body">
                                   <table class="table">
										<thead>
											<th>Departamento</th>
											<th>Cantidad</th>
										</thead>
										<tbody>
											<tr>
												<td></td>
												<td></td>
											</tr>
										</tbody>
								   </table>
	                           </div>
	                       </div>
	                       
	                       <div class="panel panel-default">
	                           <div class="panel-heading">
	                               COVID-19
	                           </div>
	                           <div class="panel-body">
	                               By <a href="" target="_blank">Junior Tello</a></a>
	                           </div>
	                       </div>
	                   </div>	                   
	               </div>
	           </section>
	           
	           <section class="tab-pane fade" id="configuration">
	               <nav class="subbar">
			            <ul class="nav nav-tabs">
				            <li class="active"><a href="#access" data-toggle="tab"><i class="fa fa-code"></i> <span>System</span></a></li>
				            <li><a href="#roles" data-toggle="tab"><i class="fa fa-user"></i> <span>Roles</span></a></li>
			            </ul>
		            </nav>
		            
		            <section class="tab-content content">
		                <section class="tab-pane active fade in" id="access">
                            <div class="row">
                                <div class="col-xs-12">
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/><br/>
	                                    </div>
	                                </div>
	                            </div>
	                            
	                            <div class="col-xs-12 col-sm-4">
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/><br/>
	                                    </div>
	                                </div>
	                            </div>
	                            
	                            <div class="col-xs-12 col-sm-4">
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/><br/>
	                                    </div>
	                                </div>
	                            </div>
	                            
	                            <div class="col-xs-12 col-sm-4">
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/><br/>
	                                    </div>
	                                </div>
	                            </div>
                            </div>
		                </section>
		                
		                <section class="tab-pane fade" id="roles">
		                    <div class="row">
                                <div class="col-xs-12 col-sm-8 col-md-9">
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
	                                    </div>
	                                </div>
	                            </div>
	                            <div class="hidden-xs col-sm-4 col-md-3">
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/>
	                                    </div>
	                                </div>
	                                
	                                <div class="panel panel-default">
	                                    <div class="panel-heading">
	                                        Something
	                                    </div>
	                                    <div class="panel-body">
	                                        <br/><br/><br/>
	                                    </div>
	                                </div>
	                            </div>
	                       </div>
		                </section>
		            </section>
	           </section>
	           
	           <section class="tab-pane fade" id="users">
	           </section>
	           
	           <section class="tab-pane fade" id="mail">
	           </section>
	        </section>
	    </section>
	</article>

	<script>
		$('#pais').select2();
		$('#pais').val('PE');
		$('#pais').trigger('change');

		window.onload = function () {
			var chart = new CanvasJS.Chart("chartContainer", {
			title:{
				text: "Casos de coronavirus en el Peru"
			},
			axisY:[{
				title: "Cantidad",
				lineColor: "#C24642",
				tickColor: "#C24642",
				labelFontColor: "#C24642",
				titleFontColor: "#C24642",
				// suffix: "k"
			}],
			toolTip: {
				shared: true
			},
			legend: {
				cursor: "pointer",
				itemclick: toggleDataSeries
			},
			data: [
			{
				type: "line",
				name: "Confirmados",
				color: "#428bca",
				showInLegend: true,
				// axisYIndex: 1,
				dataPoints: [
					<?php foreach($datos['confirma'] as $confrm): ?>
						{ x: new Date(<?php echo $confrm['anio'] ?>, <?php echo $confrm['mes'] ?>, <?php echo $confrm['dia'] ?>), y: <?php echo $confrm['cantidad'] ?> },
					<?php endforeach; ?>
				]
			},
			{
				type: "line",
				name: "Recuperados",
				color: "#3c763d",
				// axisYIndex: 0,
				showInLegend: true,
				dataPoints: [
					<?php foreach($datos['recuperado'] as $confrm): ?>
						{ x: new Date(<?php echo $confrm['anio'] ?>, <?php echo $confrm['mes'] ?>, <?php echo $confrm['dia'] ?>), y: <?php echo $confrm['cantidad'] ?> },
					<?php endforeach; ?>
				]
			},
			{
				type: "line",
				name: "Muertes",
				color: "#a94442",
				// axisYType: "secondary",
				showInLegend: true,
				dataPoints: [
					<?php foreach($datos['muerte'] as $confrm): ?>
						{ x: new Date(<?php echo $confrm['anio'] ?>, <?php echo $confrm['mes'] ?>, <?php echo $confrm['dia'] ?>), y: <?php echo $confrm['cantidad'] ?> },
					<?php endforeach; ?>
				]
			}]
		});
		chart.render();

		function toggleDataSeries(e) {
			if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
				e.dataSeries.visible = false;
			} else {
				e.dataSeries.visible = true;
			}
			e.chart.render();
		}

}

	</script>
	
	
	<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>


</body>
</html><?php /**PATH C:\xampp\htdocs\covid19\covid\resources\views/inicio.blade.php ENDPATH**/ ?>