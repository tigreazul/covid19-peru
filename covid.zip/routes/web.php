<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('imports', function () {
//     return 'xxxx';
// });

Route::get('/','InicioController@index')->name('inicio');
Route::get('pais','InicioController@paises')->name('paises');
Route::post('paises','InicioController@paises')->name('paises');

Route::get('historial','InicioController@historial')->name('historial');

Route::get('imports', 'InicioController@viewimport')->name('viewimport');
Route::post('import', 'InicioController@importCsv')->name('import');

Route::post('import-confirmado', 'InicioController@imporConfirmadoCsv')->name('historial.confirmado');
Route::post('import-recuperado', 'InicioController@imporRecuperadoCsv')->name('historial.recuperado');
Route::post('import-muerte', 'InicioController@imporMuertoCsv')->name('historial.muerte');